fav_number = 27
print('''My favourite number has 2 digits
The first one is the first prime
and the second one is the 4th prime
        -------------
        Answer: ''', fav_number)
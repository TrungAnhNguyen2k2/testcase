"""
Author: Tris1702
Github: https://github.com/Tris1702
Gmail: phuonghoand2001@gmail.com
Thank you so much!
"""
a = int (input())
if a%2 == 0:
    print('CHAN')
else:
    print('LE')
c1 = 5 + 1.3j
c2 = 6 + 1.5j
print(c2+c1)
print(c2-c1)
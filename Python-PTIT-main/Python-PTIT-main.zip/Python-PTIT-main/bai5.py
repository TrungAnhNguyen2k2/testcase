s1 = "Chao PTIT"
s2 = " mung den voi"
s3 = s1[:len(s1)//2] + s2 + s1[len(s1)//2:]
print(s3)
first_name = "Hoa"
last_name = "Co Thi Phuong"

print(f"My name is {last_name} {first_name}")
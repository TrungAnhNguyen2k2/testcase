"""
Author: Tris1702
Github: https://github.com/Tris1702
Gmail: phuonghoand2001@gmail.com
Thank you so much!
"""
s = input()
if int(s[0]) + int(s[4]) == int(s[8]):
    print('YES')
else:
    print('NO')
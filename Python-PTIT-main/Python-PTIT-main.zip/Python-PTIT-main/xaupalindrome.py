"""
Author: Tris1702
Github: https://github.com/Tris1702
Gmail: phuonghoand2001@gmail.com
Thank you so much!
"""

s = input()
if len(s) > 1: print(len(s)-1)
else: print(0)